/* var draw = SVG().addTo('body').size(500, 300);
draw.attr('id', 'canvas'); */

// Agafar ids
var existingSvg = document.getElementById('canvas');
var draw = SVG.adopt(existingSvg);
var name_input = document.getElementById('name_input');
var text = draw.text("");

var fontSize = document.getElementById('fontSize');
var font = document.getElementById('font');
var bt_download = document.getElementById('bt_download');


function changePosition(draw, text, from){
    var svgWidth = draw.width();
    var svgHeight = draw.height();
    var textWidth = text.bbox().width;
    var textHeight = text.bbox().height;
    if(from == "name_input"){
        text.move(((svgWidth-textWidth)/2)+(textWidth/2), ((svgHeight-textHeight)/2)-(textHeight/2));
    }else{
        text.move(((svgWidth-textWidth)/2), ((svgHeight-textHeight)/2));
    }
    text.attr({ 'text-anchor': 'middle', 'dominant-baseline': 'middle' });
};

// Listener text field
name_input.addEventListener('input', function(){
    text.clear();
    var textValue = document.getElementById('name_input').value;
    var valueSize = document.getElementById('fontSize').value;
    var valueFont = document.getElementById('font').value;
    text = draw.text(textValue);
    text.move(0, 0).font({ fill: '#f06', family: valueFont, size: valueSize });
    changePosition(draw, text, "name_input");
});

// Listener font size
fontSize.addEventListener('change', function(){
    var fontSizeValue = document.getElementById('fontSize').value;
    text.font({size: fontSizeValue});
    changePosition(draw, text, "fontSize");
});

// Listener font
font.addEventListener('change', function(){
    var fontValue = document.getElementById('font').value;
    text.font({family:fontValue});
    changePosition(draw, text, "font");
})

// Listener download
bt_download.addEventListener('click', function(){
    var ns = document.getElementById('canvas');

    // Create Blob object
    var svgData = new XMLSerializer().serializeToString(ns);
    var blob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });

    // Create URL for Blob
    var blobUrl = URL.createObjectURL(blob);

    // Create download link
    var link = document.createElement("a");
    link.href = blobUrl;
    var name = document.getElementById('name_input').value;
    name = name.toLowerCase();
    link.download = name+".svg";

    // Add document link to document to start de download
    document.body.appendChild(link);
    link.click();

    // Clean URL object
    document.body.removeChild(link);
    URL.revokeObjectURL(blobUrl);

});